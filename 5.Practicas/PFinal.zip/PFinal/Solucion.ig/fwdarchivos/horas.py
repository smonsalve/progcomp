import csv

archivos = open("indice.txt")
f = open("saldas.csv",'w')
for line in archivos:
	with open(line.rstrip('\n'), 'rb') as csvfile:
		reader = csv.reader(csvfile, delimiter=',')
		for row in reader:
			if (row[2])!="  ":
				f.write(row[2] + "," + row[3] + "," +row[4] + "," +row[5] + "," + row[6] + "," + row[7] + "," +row[8] + "," +row[9]+'\n')