from datetime import *
import csv



# a = ( 1,"0000000191","0000000058", 6,38, 4,20,2016)
# b = ( 1,"0000000191","0000000058", 6,38, 4,20,2016)
# c = ( 1,"0000000295","0000000058", 6,41, 4,20,2016)
# d = ( 2,"0000000302","0000000000", 7,49, 4,20,2016)
# e = ( 2,"0000000438","0000000000", 9,32, 4,20,2016)
# f = ( 2,"0000000205","0000000000",14,32, 4,20,2016)

# a1 = datetime(16,4,20,14,32)
# b1 = datetime(b[7],b[5],b[6],b[3],b[4])
# f1 = datetime(f[7],f[5],f[6],f[3],f[4])
# delta = f1-b1 
# print delta

# class persona:

# 	def __init__(self,cod, dep):
# 		self.cod = cod
# 		self.dep = dep

# 	def __str__(self):
# 		return str(self.cod) + " " + self.dep

# a = persona(1,2)


# print a

d1 = datetime(2016,05,20,10,00)
d2 = datetime(2016,05,21,22,00)

print d2-d1

def proces(): 
	archivo = "saldas.csv"
	f = open("Ing.csv",'w')
	g = open("Egr.csv",'w')
	with open(archivo, 'rb') as csvfile:
		reader = csv.reader(csvfile, delimiter=',')
		for row in reader:
			if (row[0]=="1"):
				f.write(row[1] + "," + row[2] + "," +row[7] + "," + row[5] + "," + row[6] + "," +row[3] + "," +row[4]+'\n')
				#print 
			else:
				g.write(row[1] + "," + row[2] + "," +row[7] + "," + row[5] + "," + row[6] + "," +row[3] + "," +row[4]+'\n')
				#print 